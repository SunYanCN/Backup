---
title: 代码
date: 2018-10-24 19:52:03
---


1. Tensorflow
```python
# with tf.Session() as sess

import tensorflow as tf

a = tf.constant(2)
b = tf.constant(3)

with tf.Session() as sess:
    print(sess.run(a+b))
```

2. TesnorFlow
```python
# placeholder and feed_dict

a = tf.placeholder(tf.float32)
b = tf.placeholder(tf.float32)

add = tf.add(a,b)

with tf.Session() as sess:
    print(sess.run(add,feed_dict={a:1.0,b:2.0}))

3. 在语料库中选择由词频排序最高的词汇
```python
>>> from sklearn.feature_extraction.text import CountVectorizer

>>> vectorizer = CountVectorizer(min_df=0, lowercase=False,stop_words=None)
#stop_words=None表示不去掉停用词，若改为stop_words=’english’则去掉停用词
>>> vectorizer.fit(sentences)
>>> vectorizer.vocabulary_
#{'John': 0, 'chocolate': 1, 'cream': 2, 'hates': 3, 'ice': 4, 'likes': 5}
```
4. Keras打印正确率

```python
>>> loss, accuracy = model.evaluate(X_train, y_train, verbose=False)
>>> print("Training Accuracy: {:.4f}".format(accuracy))
>>> loss, accuracy = model.evaluate(X_test, y_test, verbose=False)
>>> print("Testing Accuracy:  {:.4f}".format(accuracy))
Training Accuracy: 1.0000
Testing Accuracy:  0.7960
```

5. {% fold Keras画正确率和损失 %}
```python
import matplotlib.pyplot as plt
plt.style.use('ggplot')

def plot_history(history):
    acc = history.history['acc']
    val_acc = history.history['val_acc']
    loss = history.history['loss']
    val_loss = history.history['val_loss']
    x = range(1, len(acc) + 1)

    plt.figure(figsize=(12, 5))
    plt.subplot(1, 2, 1)
    plt.plot(x, acc, 'b', label='Training acc')
    plt.plot(x, val_acc, 'r', label='Validation acc')
    plt.title('Training and validation accuracy')
    plt.legend()
    plt.subplot(1, 2, 2)
    plt.plot(x, loss, 'b', label='Training loss')
    plt.plot(x, val_loss, 'r', label='Validation loss')
    plt.title('Training and validation loss')
    plt.legend()
```
{% endfold %}

6. OneHotEncoder
```python

>>> from sklearn.preprocessing import OneHotEncoder

>>> encoder = OneHotEncoder(sparse=False)
>>> city_labels = city_labels.reshape((5, 1))
>>> encoder.fit_transform(city_labels)
array([[0., 1., 0.],
       [1., 0., 0.],
       [1., 0., 0.],
       [0., 0., 1.],
       [0., 1., 0.]])

```

7. [word2vec Tensorflow代码实例](http://nooverfit.com/wp/pycon-2016-tensorflow-%E7%A0%94%E8%AE%A8%E4%BC%9A%E6%80%BB%E7%BB%93-tensorflow-%E6%89%8B%E6%8A%8A%E6%89%8B%E5%85%A5%E9%97%A8-%E7%AC%AC%E4%BA%8C%E8%AE%B2-word2vec/)

8. {% fold TF和Keras GPU设置 %}

```python
def set_gpu(ratio = 0, target = 'memory'):
    """
    :param ratio: 配置GPU，0表示自适应，(0, 1]表示显存占比
    :param target: 选择显存大的卡(memory)还是GPU利用率(ur)低的卡
    :return:
    """
    import os
    command0 = "nvidia-smi -q -d Memory | grep -A4 GPU | grep Total | awk '{print $3}'"
    command1 = "nvidia-smi -q -d Memory | grep -A4 GPU | grep Free | awk '{print $3}'"
    command2 = "nvidia-smi -q | grep Gpu | awk '{print $3}'"
    Total_memory = list(map(int, os.popen(command0).readlines()))
    memory = list(map(int, os.popen(command1).readlines()))
    gpu = list(map(int, os.popen(command2).readlines()))
    if memory and gpu:  # 如果没有显卡，memory，gpu均为[]
        if target == 'memory':
            num = memory.index(max(memory))
        else:
            num = gpu.index(min(gpu))

        util_rate = round(100*(1-float(memory[num])/Total_memory[num]),2)
        print('>>> Using GPU%d' % num)  #当前使用的GPU
        print('>>> Free Memory       : GPU%d %6d MiB ' % (num, memory[num]))  #当前使用的GPU的空闲显存
        print('>>> Volatile GPU-Util : GPU%d   %.2f %%  ' % (num, util_rate ))  #当前使用的GPU的占用率
        print('>>> Recommend ratio   : GPU%d   %.1f ' % (num, (100-util_rate-10)/100)) #推荐ratio设置

        import tensorflow as tf
        config = tf.ConfigProto()
        config.gpu_options.visible_device_list = str(num)  # 选择GPU
        if ratio == 0:
            config.gpu_options.allow_growth = True
        else:
            config.gpu_options.per_process_gpu_memory_fraction = ratio

        sess = tf.Session(config=config)
        from keras import backend as K
        K.set_session(sess)
    else:
        print('>>> Could not find the GPU')
```
{% endfold %}
使用举例：
```python
set_gpu(ratio=0.7, target = 'memory')
```

{% fold 或者也可以使用以下代码 %}
```python
import tensorflow as tf
config = tf.ConfigProto()
config.gpu_options.visible_device_list = '0'
config.gpu_options.per_process_gpu_memory_fraction = 0.9
config.gpu_options.allow_growth = True
sess = tf.Session(config=config)
from keras import backend as K
K.set_session(sess)
```
{% endfold %}





