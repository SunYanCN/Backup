---
title: 碎片笔记
date: 2018-10-24 19:52:17
---
1. 网易云MP3外链
http://music.163.com/song/media/outer/url?id=ID数字.mp3（ID歌曲链接最后有）

2. [机器学习基础数学书](https://web.stanford.edu/~boyd/vmls/)
主要讲了向量、矩阵、最小二乘。

3. 简单的Encoder-Decoder
```python
# Encoder model
encoder_input = Input(shape=(None,len(eng_chars)))
encoder_LSTM = LSTM(256,return_state = True)
encoder_outputs, encoder_h, encoder_c = encoder_LSTM (encoder_input)
encoder_states = [encoder_h, encoder_c]

# Decoder model
decoder_input = Input(shape=(None,len(fra_chars)))
decoder_LSTM = LSTM(256,return_sequences=True, return_state = True)
decoder_out, _ , _ = decoder_LSTM(decoder_input, initial_state=encoder_states)
decoder_dense = Dense(len(fra_chars),activation='softmax')
decoder_out = decoder_dense (decoder_out)

model = Model(inputs=[encoder_input, decoder_input],outputs=[decoder_out])
# Run training
model.compile(optimizer='rmsprop', loss='categorical_crossentropy')
model.fit(x=[tokenized_eng_sentences,tokenized_fra_sentences], 
 y=target_data,
 batch_size=64,
 epochs=50,
 validation_split=0.2)
```

4. Tensorboard运行
`tensorboard --logdir="log"`

5. 使用命令行把notebook转为python文件
`jupyter nbconvert --to script [YOUR_NOTEBOOK].ipynb`

6. `np.random.rand` 返回一个或一组服从“0~1”均匀分布的随机样本值。随机样本取值范围是[0,1)，不包括1
   `np.random.randn` 返回一个或一组服从标准正态分布的随机样本值。标准正态分布是以0为均数、以1为标准差的正态分布，记为N（0，1）。

7. tf.Print(需要看的tensor, 具体要输出的数据, 输出信息的前缀, summarize=每个tensor打印的条目数量)
   `sess.run(tf.Print(w, [w, w.shape], message="w message"))`

8. [邱锡鹏:神经网络与深度学习](https://nndl.github.io/?utm_source=qq&utm_medium=social&utm_oi=560191423316701184)

9. Tqdm  功能：显示进度条
![tqdm.gif](https://i.loli.net/2018/08/09/5b6bb230ee60b.gif)

10. Yagmail  功能:邮件系统封装 注:163邮箱在设置里开启SMTP服务,密码为客户端授权码
```python 
import yagmail 
yag = yagmail.SMTP(user=&#039;1831019@163.com&#039;,password=&#039;2185aS&#039;, host=&#039;smtp.163.com&#039;) 
yag.send(to=&#039;920710@qq.com&#039;, subject = &quot;服务器运行状态&quot;, attachments=[&#039;main.py&#039;],contents=&#039;代码运行完毕,附件为结果.&#039;)
```

11. 两个多目标优化的库,有空写写这两个库的效果
- [Platypus](https://github.com/Project-Platypus/Platypus)
- [MOEA-dev](https://github.com/slow295185031/MOEA-dev)

12. [写给NLP研究者的编程指南](https://zhuanlan.zhihu.com/p/48504619?utm_source=qq&utm_medium=social&utm_oi=560191423316701184)
13. [支持多语言的文本标注工具——doccano](https://zhuanlan.zhihu.com/p/48320901)
14. [fast.ai远程jupyter服务器配置(GPU)](https://zhuanlan.zhihu.com/p/34412017)
15. [Practical Text Classification With Python and Keras](https://realpython.com/python-keras-text-classification/#installing-keras)
16. [中文命名实体识别 (TensorFlow)](https://github.com/Determined22/zh-NER-TF)
17. [动态可视化：一步步拆解LSTM和GRU](https://zhuanlan.zhihu.com/p/47907312)
18. 关于Attention和Transformer的几篇文章：、
    1. [Attention机制简单总结](https://zhuanlan.zhihu.com/p/46313756)
    2. [Attention机制详解（二）——Self-Attention与Transformer](https://zhuanlan.zhihu.com/p/47282410)
    3. [草稿纸上的seq2seq模型与Attention机制](https://zhuanlan.zhihu.com/p/46040939)
    4. [The Annotated Transformer](http://nlp.seas.harvard.edu/2018/04/03/attention.html)
    5. [聊聊 Transformer](https://zhuanlan.zhihu.com/p/47812375)
    6. [当我们在聊Attention的时候，我们实际在聊什么](https://zhuanlan.zhihu.com/p/48424395)
19. 词向量与预训练模型
   1. [自然语言处理中的语言模型预训练方法](https://zhuanlan.zhihu.com/p/47342053)
   2. [从Word Embedding到Bert模型—自然语言处理中的预训练技术发展史](https://zhuanlan.zhihu.com/p/49271699)
   3. [NLP的游戏规则从此改写？从word2vec, ELMo到BERT](https://zhuanlan.zhihu.com/p/47488095)

20. 区别迁移学习和预训练模型：
    - 把模型的所有参数保存起来, 都可以宽泛地叫做预训练, 所以预训练比迁移学习宽泛的多. 我们并不设限预训练的保存模型未来的用处 (部署 or 继续优化 or 迁移学习)
    - 把预训练的模型用在其他应用的训练可以称为迁移学习. 
21. 一个不错的AI博客：http://nooverfit.com/wp/
22. 关于代码加速的几篇文章：
    1. [python的numba加速](https://blog.csdn.net/qtlyx/article/details/78586229)
    2. [使用GPU加速numpy运算](http://www.yueye.org/2017/use-minpy-to-accelerate-numpy.html)
    3. [CUML](https://github.com/rapidsai/cuml)
    4. [TensorFlow如何充分使用所有CPU核数，提高TensorFlow的CPU使用率，以及Intel的MKL加速](http://nooverfit.com/wp/tensorflow%E5%A6%82%E4%BD%95%E5%85%85%E5%88%86%E4%BD%BF%E7%94%A8%E6%89%80%E6%9C%89cpu%E6%A0%B8%E6%95%B0%EF%BC%8C%E6%8F%90%E9%AB%98tensorflow%E7%9A%84cpu%E4%BD%BF%E7%94%A8%E7%8E%87%EF%BC%8C%E4%BB%A5/)

23. [Google图片压缩工具](https://squoosh.app/)
24. Adaptive Softmax for Keras
    - [论文](https://arxiv.org/abs/1609.04309)
    - [代码](https://github.com/johntrimble/adaptive-softmax-keras)
    - [博客](https://medium.com/@dwbressler/speed-up-your-deep-learning-language-model-up-to-1000-with-the-adaptive-softmax-part-1-e7cc1f89fcc9)
25. [ELMo-keras 代码](https://github.com/iliaschalkidis/ELMo-keras)


    
