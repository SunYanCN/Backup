---
title: 娱乐
date: 2018-10-24 19:51:46
---

## 音乐
{% aplayerlist %}
{
    "autoplay": false,
    "showlrc": 3,
    "mutex": true,
    "music": [
        {
            "title": "盗将行",
            "author": "花粥/马雨阳",
            "url": "http://music.163.com/song/media/outer/url?id=574566207.mp3",
            "pic": "http://p1.music.126.net/-qHPT3rhxDlu5zQV9NcQ-A==/109951163555860423.jpg"
        },
        {
            "title": "藏",
            "author": "徐梦圆/双笙",
            "url": "http://music.163.com/song/media/outer/url?id=534540498.mp3",
            "pic": "http://p2.music.126.net/9cySfhHshoKksSkAxwVVqw==/109951163175751210.jpg"
            
        },

        {
            "title": "云烟成雨",
            "author": "房东的猫",
            "url": "http://music.163.com/song/media/outer/url?id=513360721.mp3",
            "pic": "http://p1.music.126.net/DSTg1dR7yKsyGq4IK3NL8A==/109951163046050093.jpg"
            
        },
        
        {
            "title": "出山",
            "author": "花粥/王胜男",
            "url": "http://music.163.com/song/media/outer/url?id=1313354324.mp3",
            "pic": "http://p1.music.126.net/xUAfdMHdXhu3BmO4g8nOYA==/109951163573311341.jpg"
        },
        {
            "title": "红昭愿",
            "author": "音阙诗听",
            "url": "http://music.163.com/song/media/outer/url?id=452986458.mp3",
            "pic": "http://p2.music.126.net/8ltR3o9R8uJ9_5Cc71cDhA==/109951162951242154.jpg"
        },
         {
            "title": "牵丝戏",
            "author": "银临/Aki阿杰",
            "url": "http://music.163.com/song/media/outer/url?id=30352891.mp3",
            "pic": "http://p1.music.126.net/Nd86SOcyCxU5Qu7jdZn_MQ==/7725168696876736.jpg"
        },
        {
            "title": "一生独一",
            "author": "卢焱",
            "url": "http://music.163.com/song/media/outer/url?id=572819430.mp3",
            "pic": "http://p2.music.126.net/maCaAYM1GS5sl9SaBdgfTA==/109951163348574432.jpg"
        },
         {
            "title": "可能否",
            "author": "木小雅",
            "url": "http://music.163.com/song/media/outer/url?id=569214126.mp3",
            "pic": "http://p2.music.126.net/SJYnDay7wgewU3O7tPfmOQ==/109951163322541581.jpg"
        },
        {
            "title": "一腔诗意喂了狗",
            "author": "花粥",
            "url": "http://music.163.com/song/media/outer/url?id=460542191.mp3",
            "pic": "http://p2.music.126.net/d95pQeIaep9IKy3gI0fKXw==/109951162862111882.jpg"
        }
    ]
}
{% endaplayerlist %}

## 文章
- [李诞，你放弃做的那个自己，也是我放弃的](https://mp.weixin.qq.com/s/1LgTH4e_YUSj8_2ZGpFfuQ)
- [通往未来之路 | 那些给人工智能打工的人](https://mp.weixin.qq.com/s/Orj8tNOS9W0mz5Vk6XVSMQ)

## 日记

2018年6月18日 
1. 拍毕业微视频 
2. 整理毕业论文资料准备交 
3. 世界杯竞猜的软件（马蜂窝旅游）

#### 2018年7月1日 
毕业设计的事情弄的我头都疼，把该扔的东西一扔，离开了生活了四年的学校，没有多不舍，真的。四年的生活总结一下就是我是被胁迫的，不知道是我对待方式不对还是其他的问题，懒得去想，我想专心致志的去开始下一段生活了，希望一切愉快。 附一个我在知乎上的回答：在中北大学就读是怎样的一种体验？ - 心若向阳的回答 - 知乎https://www.zhihu.com/question/28515516/answer/368684610 
#### 2018年7月11日 
前两天到的华科，华科本校区没有给外校保研生安排住宿宿舍，在老师的安排下到鄂州工研院这边学习。问学姐要带什么东西，学姐说这里吃住免费。到这里一看，果然如此呀，生活用品全部发，床单被罩被子也发，吃饭免费，爽的不行。好好学习，报效老师！
#### 2018年8月30号
 总结一下鄂州这边的生活和学习情况。 这边远离市区，环境比较单纯，但是娱乐方面和生活的便利质量都不是很高。 学习方面，主要做了自然语言处理的事情，接触最多的可能是RNN和词向量这块，有时间系统的总结一下。目前想做的是一个seq2seq的一个对话系统，然后做Rnet的，做DMN的，分别测试一下效果。
#### 2018年9月2日 
明天正式开学，前天晚上刚从鄂州研究院回来，把东西搬到宿舍。不知道是不是我宿舍选的问题，有点陈旧，还没阳台和卫生间，有点失望。把校园卡和校园网办了一下，买了点生活用品，感觉一切都基本进去状态了。目前的计划有以下几点： 1. 继续做对话系统。 2. 沈阳自动化所的两个项目的结题，最好能写成一个专利。 3. 体检的时候好好检查一下身体，肩膀最近肌肉有点疼，不知道是不是拉伤了。 4. 跑能耗优化的实验。
#### 2018年9月4日 
今天看到一篇很不错的文章，讲如何看待自己出身不是名校的问题： 生而为人，为什么会这么容易受别人的影响？ > 如果你出身名校，请用欣赏的眼光看别人； > 如果你出身普通的学校，请用欣赏的眼光看自己； 其实我觉得，反正都不是了，后悔并没有什么用，不如好好提高自己的实力，才能腰杆站直。  另一个看到李纪为做的一家公司，[香农科技](http://shannon.ai)，他也是做的对话系统方向，斯坦福大学三年博士毕业，很厉害，公司主要做自然语言处理在金融领域的应用。 

#### 2018年11月11日
