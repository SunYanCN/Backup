---
title: Google Colab免费GPU服务器使用教程
date: 2018-10-29 20:50:22
categories:  工具
tags: GPU
---
![](https://i.loli.net/2018/10/29/5bd707070a49e.png)
## 地址
{% btn https://colab.research.google.com/notebooks/welcome.ipynb , 跳转至Colab, share fa-lg fa-fw %}（需要梯子，谷歌访问助手即可访问）
<!--more-->

## 使用方法
参见下面博客的链接，经过测试没有问题。{% btn https://blog.csdn.net/cocoaqin/article/details/79184540, 跳转至博客, share fa-lg fa-fw %}

## 数据的上传下载
参见下面博客的链接，经过测试也没有问题。{% btn https://blog.csdn.net/ssssdbucdbod/article/details/80397808?utm_source=blogxgwz0, 跳转至博客, share fa-lg fa-fw %}

## TPU的使用方法
[手把手教你在Google Colab里把谷歌TPU用起来](https://zhuanlan.zhihu.com/p/46903363)
