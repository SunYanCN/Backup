---
title: Hadoop集群基本配置
date: 2018-11-05 19:44:30
categories: 项目
tags: Hadoop
---



## 集群规划

| 集群节点分配 |                 |
| ------------ | --------------- |
| 主机名       | 主机IP          |
| master       | 192.168.100.100 |
| slave1       | 192.168.100.101 |
| slave2       | 192.168.100.102 |
| slave3       | 192.168.100.103 |

<!--more-->

| 软件版本 |                   |
| -------- | ----------------- |
| 软件名称 | 版本号            |
| Java     | 1.8.0_152         |
| CentOS   | CentOS-7-x64-1708 |
| Hadoop   | 2.7.5             |
| MySQL    | 5.7.20            |
| Hive     | 2.3.2             |

| 各软件安装路径 |                       |
| -------------- | --------------------- |
| Hadoop         | /opt/SoftWare/Hadoop/ |
| Java           | /opt/SoftWare/Java/   |
| Hive           | /opt/SoftWare/Hive    |
| MySQL          | /opt/SoftWare/MySQL   |

## 各主机基础软件安装及操作

由于使用的是最小化安装，因此这里需要安装不少软件才能进行后续操作。

### openssh安装，便于远程上传文件

```shell
[root@master ~]# yum -y install openssh-clients
```

### 同步时间工具

```shell
#安装ntpdate工具
[root@master ~]# yum -y install ntp ntpdate
#设置与网络时间同步
[root@master ~]# ntpdate cn.pool.ntp.org
#系统时间写入硬件时间
[root@master ~]# hwclock --systohc
```

### 文件上传(rz)下载(sz)工具

可以在Xshell工具中通过rz调出上传文件的窗口进行文件上传，也可以通过sz 文件名下载某一个文件。

```shell
[root@master ~]# yum -y install lrzsz
```

### 安装网络下载工具 wget

```shell
[root@test ~]# yum -y install wget
```

###  关闭防火墙

```shell
#查看防火墙开启状态
[root@test ~]# systemctl status firewalld
#关闭防火墙
[root@test ~]# systemctl stop firewalld
#禁止开机启动防火墙
[root@test ~]# systemctl disable firewalld
#开启防火墙
[root@test ~]# systemctl start firewalld
#设置开机启动防火墙
[root@test ~]# systemctl enable firewalld
#重启防火墙
[root@test ~]# systemctl restart firewalld
```

## 配置SSH免密码登录

四台主机均按照步骤2安装基础软件工具（这里不再过多叙述）

修改hosts文件，添加以下内容，四台主机均进行操作

```shell
[root@master ~]# vi /etc/hosts
#127.0.0.1   localhost localhost.localdomain localhost4 localhost4.localdomain4
#::1         localhost localhost.localdomain localhost6 localhost6.localdomain6
192.168.100.100 master
192.168.100.101 slave1
192.168.100.102 slave2
192.168.100.103 slave3
```

配置SSH免密码登录

```shell
#每台机器先使用ssh执行以下，以在主目录产生一个.ssh 文件夹
[root@master ~]# ssh master
#然后输入no即可
#每台机器均进入~/.ssh 目录进行操作
[root@master ~]# cd ~/.ssh
#输入以下命令，一路回车，用以产生公钥和秘钥
[root@master .ssh]# ssh-keygen -t rsa -P ''
#出现以下信息说明生成成功
Generating public/private rsa key pair.
Enter file in which to save the key (/root/.ssh/id_rsa): 
Your identification has been saved in /root/.ssh/id_rsa.
Your public key has been saved in /root/.ssh/id_rsa.pub.
The key fingerprint is:
SHA256:6YO1h1emM9gcWvv9OT6ftHxLnjP9u8p25x1o30oq3No root@master
The key's randomart image is:
+---[RSA 2048]----+
|                 |
|                 |
|                 |
|         .       |
|        S o o    |
|       + O *  .  |
|      . B.X. o.+.|
|         +o=+=**%|
|          .oEo*^^|
+----[SHA256]-----+
#将每台机器上的id_rsa.pub公钥内容复制到authorized_keys文件中
[root@master .ssh]# cp id_rsa.pub authorized_keys
#将所有的authorized_keys文件进行合并（最简单的方法是将其余三台slave主机的文件内容追加到master主机上）
[root@slave1 .ssh]# cat ~/.ssh/authorized_keys | ssh root@master 'cat >> ~/.ssh/authorized_keys'
[root@slave2 .ssh]# cat ~/.ssh/authorized_keys | ssh root@master 'cat >> ~/.ssh/authorized_keys'
[root@slave3 .ssh]# cat ~/.ssh/authorized_keys | ssh root@master 'cat >> ~/.ssh/authorized_keys'
#查看master上的authorized_keys文件内容，类似如下即可
[root@master .ssh]# more authorized_keys 
ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQC5iw8+LlLxo0d77uaTChOKKJqfMHzp2jgzqV2hFAneFXqqWmr
Z4/FrMUPenmdss19bP4Up9G7PGbJu29yZDvkDwlmuqnVajYyDOsCl7PPXPWXMIlxMGUHgSXLnQQi6QnWp04vJKDs0EbiRTd0ZYCSQefzJcZ8jbQ7bLYt6jtil7FfUupTdHTeexKKd8Mq3K7YFZHumKvhzs6wWiM+n41jANS083ss3OYmAdO2cU0w1BhLVvJhdzd6fNG3RXVCXI2v0XxCUHiqI9Oewl2qPOfKzeyy09bJxo371Ezjmt8GMrkA/Ecepkvx12qwNzC9bSPLfbnPWVo2gIxe4mMaFqCFJ root@master
ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQC3CkB3Jejavt+yFphsbciktWciJmbcUBOv3ZLPVLW18ZxXGZK
vG50EPXo/4By7P6IRW0wCa5YuckQEW+q6kmSatxqJ8e/K9a1mAk13N4f7V7M71Nn8IkujlF3gHYjKrmnEWpGJCy5YBURzywIQTRArlIac1xj2SeM6q+gTMV9WrAKJupIRHli+W0kHVaYHNdKl7KMUT4KVrSl+h4wFwAd7Tcyj7JIbUcCCL6o/v/LqGFwpcJfbfUsuKJJho+tImh41j7mSXR8kRbTSZkcq5KX+iANrANwOHZ58tV5KXmMQjuVq7aJ985C16hHssB6zq/zjAxpxAyQIeE8Incc8U8ix root@slave1
ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQC//uaMbzbkYqxdgZJSdq+gdQYldzMQ7D3SxsUaNO5oVnVOszw
+mbNnmL8vp1EUUehabQHPCAvCmLKUPXzfcxlyJEF/pnY77u4ySwsRVEpHvsDZbrclgCOrS6hW00sSx303KHLOgXT70LfrmnohfUhvTxajzLXT+C8f5ZfTZ8meKD73HKl16jRwZQ8YhW9GUyuCkgQTGtKtTKPsRUd9LpAc/7/u8xvvvNvTYPxgyTJcUMzGSOHh8J3upI54ykY0FgBkjs1fCUaDalxAgsHw9B1iyx706WbcT6ymiQVMKGnnnM6k2KPvUvfDswVfUSG+4ZsYSRHRTgWuiBbHoIr7DVd root@slave2
ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDDTzTTdGRTd1zts3m7uKobcgRom4lVyF9EdNOdbBWMucYjbCs
BgP1ideDDQed2TyBj3Szz3Yx6h1L4McGmATY/D9qRLml26VW/x0Tod8JYkqOQpQL9knLW2cwITnhLzq5VDugOix06r/uweP3Zed9CO7ld3jUxJJNZCYpsNz+eUKq9SWM5+ehUu9pfZZu9zUk7Q01js3uCHzu1AhsajgNzgB4+YLLccdHBfxGg4ix5wuaF82PlEEh70hTdfRkq8pqPMZ+FIQtTgfD5XllKTcnPItUY23hc7Umx4I3ujOd810vzffWYK07cOtv1r7LEcYtYqbZ6zIvII+M775iRkzQX root@slave3

#将master上的authorized_keys文件分发到其他主机上
[root@master .ssh]# scp ~/.ssh/authorized_keys root@slave1:~/.ssh/
[root@master .ssh]# scp ~/.ssh/authorized_keys root@slave2:~/.ssh/
[root@master .ssh]# scp ~/.ssh/authorized_keys root@slave3:~/.ssh/
#每台机器之间进行ssh免密码登录操作，包括自己与自己
[root@master ~]# ssh master
[root@master ~]# ssh slave1
[root@slave1 ~]# ssh master
[root@master ~]# ssh slave2
[root@slave2 ~]# ssh master
[root@master ~]# ssh slave3
[root@slave3 ~]# ssh master
[root@master ~]# ssh slave1
[root@slave1 ~]# ssh slave1
[root@slave1 ~]# ssh slave2
[root@slave2 ~]# ssh slave1
[root@slave1 ~]# ssh slave3
[root@slave3 ~]# ssh slave1
[root@slave1 ~]# ssh slave2
[root@slave2 ~]# ssh slave2
[root@slave2 ~]# ssh slave3
[root@slave3 ~]# ssh slave2
[root@slave2 ~]# ssh slave3
[root@slave3 ~]# ssh slave2
[root@slave2 ~]# ssh slave3
[root@slave3 ~]# ssh slave3
```

## 安装配置Java环境并测试

## 下载jdk

下载地址：<http://www.oracle.com/technetwork/java/javase/archive-139210.html> 

### 卸载其他jdk

如果centos中已经安装的有jdk，则需要先卸载当前jdk，重新安装新的jdk

```shell
#查询当前所有安装的jdk版本
[root@master ~]# rpm -qa|grep jdk
#如果什么都没有展示说明没有已安装的jdk，则无需卸载，如果出现以下jdk，则卸载之
copy-jdk-configs-2.2-3.el7.noarch
java-1.8.0-openjdk-1.8.0.131-11.b12.el7.x86_64
java-1.8.0-openjdk-headless-1.8.0.131-11.b12.el7.x86_64
#卸载jdk，使用下面的方法卸载即可
[root@master ~]# yum -y remove copy-jdk-configs-2.2-3.el7.noarch
#再次查询当前所有安装的jdk版本
[root@master ~]# rpm -qa|grep jdk
```

 ### 开始安装jdk

```shell
#在master主节点上创建指定目录#
[root@master ~]# mkdir -p /opt/SoftWare/Java
[root@master ~]# mkdir -p /opt/SoftWare/Hadoop
#进入到Java目录
[root@master ~]# cd /opt/SoftWare/Java
#使用rz命令从windows主机上传jdk压缩包到master节点
[root@master Java]# rz
#解压到当前目录
[root@master Java]# tar -zxvf jdk-8u152-linux-x64.tar.gz 
#配置环境变量
[root@master Java]# vi /etc/profile
#在该文件后面追加一下内容
export JAVA_HOME=/opt/SoftWare/Java/jdk1.8.0_152
export JRE_HOME=/opt/SoftWare/Java/jdk1.8.0_152/jre
export CLASSPATH=.:$JAVA_HOME/lib/dt.jar:$JAVA_HOME/lib/tools.jar:$JRE_HOME/lib/rt.jar
export PATH=$PATH:$JAVA_HOME/bin:$JRE_HOME/bin
#使刚才的设置生效
[root@master Java]# source /etc/profile
#检测是否配置成功
[root@master Java]# java -version
java version "1.8.0_152"
Java(TM) SE Runtime Environment (build 1.8.0_152-b16)
Java HotSpot(TM) 64-Bit Server VM (build 25.152-b16, mixed mode)
#其他主机同样的操作进行即可
```

## 安装配置Hadoop并配置

### 下载Hadoop到本地

 下载地址：<http://hadoop.apache.org/releases.html>

### 上传至master节点

```shell
#上传
[root@master ~]# cd /opt/SoftWare/Hadoop
[root@master Hadoop]# rz
#解压
[root@master Hadoop]# tar -zxvf hadoop-2.7.5.tar.gz
```

### 创建目录

```shell
#进入hadoop-2.7.5主目录
[root@master Hadoop]# cd hadoop-2.7.5
#创建以下目录，以备后用
[root@master hadoop-2.7.5]# mkdir tmp
[root@master hadoop-2.7.5]# mkdir logs
[root@master hadoop-2.7.5]# mkdir -p hdfs/name
[root@master hadoop-2.7.5]# mkdir -p hdfs/dat
```

### 修改配置

